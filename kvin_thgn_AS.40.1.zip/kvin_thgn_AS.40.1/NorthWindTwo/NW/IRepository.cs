﻿using System.Collections.Generic;
using NorthWindTwo.Entities;
using NorthWindTwo.Report;
using NorthWindTwo.Report.DTO;

namespace NorthWindTwo.NW
{
    /// <summary>
    /// Interface for a repository
    /// </summary>
    public interface IRepository
    {
        List<Product> Products();
        List<Category> Categories();
        List<Order> Orders();
        List<Order_Detail> OrderDetails();
        List<Employee> Employees();
        List<Customer> Customers();
        void CreateOrder(Order order);
        Report<List<OrdersByTotalPriceDto>, ReportError> TopOrdersByTotalPrice(int count);
        Report<List<ProductsBySaleDto>, ReportError> TopProductsBySale(int count);
        Report<EmployeeSaleDto, ReportError> EmployeeSale(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind
{
    /// <summary>
    /// Class containing information about an Order_Detail
    /// </summary>
    public class Order_Details
    {
        public Orders OrderID { get; set; }
        public Products ProductID { get; set; }
        public decimal UnitPrice { get; set; }
        public short Quantity { get; set; }
        public float Discount { get; set; }

        public Order_Details(Orders orderId, Products productId, decimal unitPrice, short quantity, float discount)
        {
            OrderID = orderId;
            ProductID = productId;
            UnitPrice = unitPrice;
            Quantity = quantity;
            Discount = discount;
        }
    }
}

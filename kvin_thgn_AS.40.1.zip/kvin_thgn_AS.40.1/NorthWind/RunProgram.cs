﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Northwind
{
    /// <summary>
    /// Class containing main method using the NorthWind class.
    /// </summary>
    public class RunProgram
    {
        public static void Main(string[] args)
        {
            IRepository rep = new Repository();
            var nw = new NorthWind(rep);
            nw.Subscribe();
            nw.Subscribe();
            nw.AddOrder(new DateTime(), "Hello", "123", "city", "region", "2900", "dk");
            nw.Unsubscribe();
            nw.Unsubscribe();
            var products = nw.Products.Take(5);
            foreach (var product in products)
            {
                Console.WriteLine(product.ProductName);
            }
            var orders = nw.Orders;
            var count =
                orders.GroupBy(i => i.ShipCountry)
                    .Select(i => new {Country = i.Key, Count = i.Count()})
                    .OrderByDescending(i => i.Count);
            foreach (var c in count)
            {
                Console.WriteLine(c.Country + ": " + c.Count);
            }
        }
    }
}

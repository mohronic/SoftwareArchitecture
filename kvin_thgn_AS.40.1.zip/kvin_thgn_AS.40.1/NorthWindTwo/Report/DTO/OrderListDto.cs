﻿using System;
using System.Collections.Generic;

namespace NorthWindTwo.Report.DTO
{
    /// <summary>
    /// DTO containing information about an order, used in the EmployeeSaleDTO
    /// </summary>
    public class OrderListDto
    {
        public int OrderId { get; set; }
        public DateTime? OrderDate { get; set; }
        public decimal TotalPrice { get; set; }
        public List<ProductListDto> Products { get; set; } 
    }
}

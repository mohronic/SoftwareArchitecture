﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Calendar_System.AccountSubSystem;
using Calendar_System.EntrySubSystem;
using Calendar_System.MainSystem;
using Calendar_System.StorageSubSystem;
using Calendar_System.Utility;

namespace Calendar_System
{
    class Program
    {
        // If you want to run as user in current implementation
        // Username is Hans (case sensitive!) and password is 12345.
        static void Main()
        {
            CalendarControl cControl = new CalendarControl();
        }
    }
}

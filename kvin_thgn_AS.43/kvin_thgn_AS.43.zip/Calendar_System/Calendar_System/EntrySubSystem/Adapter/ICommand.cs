﻿namespace Calendar_System.EntrySubSystem.Adapter
{
    public interface ICommand
    {
        void Execute();
    }
}

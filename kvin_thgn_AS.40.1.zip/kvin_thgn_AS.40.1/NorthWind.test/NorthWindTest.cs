﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Northwind;


namespace NorthWind.test
{
    [TestClass]
    public class NorthWindTest
    {
        private Northwind.NorthWind _nw;

        [TestInitialize]
        public void Init()
        {
            _nw = new Northwind.NorthWind(new Northwind.Repository("test"));
        }

        [TestMethod]
        public void GetAllTest()
        {
            Assert.AreEqual(_nw.Orders.Count, 0);
            Assert.AreEqual(_nw.Products.Count, 0);
        }

        [TestMethod]
        public void AddOrderTest()
        {
            _nw.AddOrder(new DateTime(), "test", "test", "test", "test", "test", "test");
            Assert.AreEqual(_nw.Orders.Count, 1);
            Assert.AreEqual(_nw.Orders[_nw.Orders.Count-1].OrderID, 1);
        }
    }
}

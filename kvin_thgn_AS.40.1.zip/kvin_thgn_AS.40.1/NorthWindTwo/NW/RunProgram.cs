﻿using System;
using System.Linq;
using NorthWindTwo.CSV;
using NorthWindTwo.DB;

namespace NorthWindTwo.NW
{
    class RunProgram
    {
        public static void Main(string[] args)
        {
            IRepository rep = new RepositoryNw();
            var nw = new NorthWindClient(rep);
            nw.NewOrderEvent += NewOrderHandler;
            var order = nw.AddOrder(new DateTime(1990, 2, 23), "Hello", "123", "city", "region", "2900", "dk");
            Console.WriteLine(order.OrderID);
            var products = nw.Products.Take(5);
            foreach (var product in products)
            {
                Console.WriteLine(product.ProductName);
            }
            var orders = nw.Orders;
            var count =
                orders.GroupBy(i => i.ShipCountry)
                    .Select(i => new { Country = i.Key, Count = i.Count() })
                    .OrderByDescending(i => i.Count);
            foreach (var c in count)
            {
                Console.WriteLine(c.Country + ": " + c.Count);
            }

        }

        /// <summary>
        /// Method used the the NewOrderEventHandler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void NewOrderHandler(object sender, NewOrderEventArgs e)
        {
            Console.WriteLine(e.Order.OrderID + ", " + e.Order.OrderDate);
        }
    }
}

﻿using System;

namespace Calendar_System.MainSystem
{
    class CalendarWeekly : ÁbstractCalendar
    {

    }
}
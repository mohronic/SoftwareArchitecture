﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendar_System.view
{
    class CalendarWeekly : ÁbstractCalendar
    {

        public override void Update()
        {
            throw new NotImplementedException();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind
{
    /// <summary>
    /// Repository for the CSV file.
    /// </summary>
    public class Repository : IRepository
    {
        public List<Categories> CatList;
        public List<Products> ProList;
        public List<Orders> OrdList;
        public List<Order_Details> ODeList;

        /// <summary>
        /// Creates the repository and calls load()
        /// </summary>
        public Repository()
        {
            ODeList = new List<Order_Details>();
            load();
        }

        /// <summary>
        /// To create an empty repository for the test
        /// </summary>
        /// <param name="test"></param>
        public Repository(String test)
        {
            CatList = new List<Categories>();
            ProList = new List<Products>();
            OrdList = new List<Orders>();
            ODeList = new List<Order_Details>();
        }

        /// <summary>
        /// Loads the data from the CSV file
        /// </summary>
        private void load()
        {
            var cd = new Dictionary<int, Categories>(); ;
            var pd = new Dictionary<int, Products>();
            var old = new Dictionary<int, Orders>();
            var reader = new StreamReader("D:/ITU/BDSA/Northwind/categories.csv");
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                int id;
                int.TryParse(values[0], out id);
                cd.Add(id, new Categories(id, values[1], values[2]));
            }
            reader.Dispose();
            reader = new StreamReader("D:/ITU/BDSA/Northwind/products.csv");
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                var id = int.Parse(values[0]);
                var sId = int.Parse(values[2]);
                var cId = int.Parse(values[3]);
                Categories cat;
                cd.TryGetValue(cId, out cat);
                var unitPrice = decimal.Parse(values[5]);
                var unitStock = short.Parse(values[6]);
                var unitOrder = short.Parse(values[7]);
                var reoLvl = short.Parse(values[8]);
                var con = int.Parse(values[9]);
                var disc = Convert.ToBoolean(con);

                pd.Add(id, new Products(id, values[1], sId, cat, values[4], unitPrice, unitStock, unitOrder, reoLvl, disc));
            }
            reader.Dispose();
            reader = new StreamReader("D:/ITU/BDSA/Northwind/orders.csv");
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                var id = int.Parse(values[0]);
                var eId = int.Parse(values[2]);
                var od = (values[3] != "") ? Convert.ToDateTime(values[3]) : new DateTime?();
                var rd = (values[4] != "") ? Convert.ToDateTime(values[4]) : new DateTime?();
                var sd = (values[5] != "") ? Convert.ToDateTime(values[5]) : new DateTime?();
                var shipV = int.Parse(values[6]);
                var freight = decimal.Parse(values[7]);

                old.Add(id, new Orders(id, values[1], eId, od, rd, sd, shipV, freight, values[8], values[9], values[10], values[11], values[12], values[13]));
            }

            reader.Dispose();
            reader = new StreamReader("D:/ITU/BDSA/Northwind/order_details.csv");
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                var oid = int.Parse(values[0]);
                var pid = int.Parse(values[1]);
                var mon = decimal.Parse(values[2]);
                var qua = short.Parse(values[3]);
                var dis = float.Parse(values[4]);

                ODeList.Add(new Order_Details(old[oid], pd[pid], mon, qua, dis));
            }

            CatList = cd.Values.ToList();
            ProList = pd.Values.ToList();
            OrdList = old.Values.ToList();
        }

        /// <summary>
        /// Returns all products
        /// </summary>
        /// <returns></returns>
        public List<Products> GetProducts()
        {
            var listOfProducts = from product in ProList select product;
            var output = listOfProducts.ToList();
            return output;
        }

        /// <summary>
        /// Returns all categories
        /// </summary>
        /// <returns></returns>
        public List<Categories> GetCategories()
        {
            var listOfProducts = from category in CatList select category;
            var output = listOfProducts.ToList();
            return output;
        }

        /// <summary>
        /// Returns all orders
        /// </summary>
        /// <returns></returns>
        public List<Orders> GetOrders()
        {
            var listOfProducts = from order in OrdList select order;
            var output = listOfProducts.ToList();
            return output;
        }

        /// <summary>
        /// Saves an order in the repository, but not to the file
        /// </summary>
        /// <param name="orders"></param>
        public void CreateOrder(Orders orders)
        {
            int maxId;
            if (OrdList != null && OrdList.Count() != 0)
            {
                maxId = OrdList.OrderByDescending(i => i.OrderID).FirstOrDefault().OrderID;
            }
            else
            {
                maxId = 0;
            }
            orders.OrderID = maxId+1;
            OrdList.Add(orders);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind
{
    /// <summary>
    /// Class containing information about a category
    /// </summary>
    public class Categories
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }

        public Categories(int categoryId, string categoryName, string description)
        {
            CategoryID = categoryId;
            CategoryName = categoryName;
            Description = description;
        }
    }
}

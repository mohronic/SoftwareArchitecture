using System;

namespace Northwind
{
    /// <summary>
    /// An event containing an order which is used when a new order is created in the NorthWind class
    /// </summary>
    public class NewOrderEventArgs : EventArgs
    {
        public Orders Order { get; set; }
    }
}
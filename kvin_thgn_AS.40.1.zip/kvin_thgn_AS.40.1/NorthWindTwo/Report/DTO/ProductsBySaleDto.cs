﻿using System.Collections.Generic;

namespace NorthWindTwo.Report.DTO
{
    /// <summary>
    /// DTO with the information of the ProductsBySale report.
    /// </summary>
    public class ProductsBySaleDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public List<UnitsSoldByMonthDto> UnitsSoldByMonth { get; set; } 
    }
}

﻿using System.Collections.Generic;

namespace NorthWindTwo.Report.DTO
{
    /// <summary>
    /// DTO used for the EmployeeSale report
    /// </summary>
    public class EmployeeSaleDto
    {
        public string EmployeeName { get; set; }
        public int? ReportsToId { get; set; }
        public List<OrderListDto> Orders { get; set; }
    }
}

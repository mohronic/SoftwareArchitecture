﻿namespace Calendar_System.StorageSubSystem
{
    class TemporaryStorage
    {

    }
}

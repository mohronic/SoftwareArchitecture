﻿using System.Collections.Generic;
using NorthWindTwo.Entities;

namespace NorthWindTwo.NW
{
    /// <summary>
    /// Interface for a repository
    /// </summary>
    public interface IRepository
    {
        List<Product> Products();
        List<Category> Categories();
        List<Order> Orders();
        List<Employee> Employees(); 
        Order CreateOrder(Order order);
    }
}

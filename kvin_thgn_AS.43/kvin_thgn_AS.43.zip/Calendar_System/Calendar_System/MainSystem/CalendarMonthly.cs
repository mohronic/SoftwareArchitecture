﻿using System;

namespace Calendar_System.MainSystem
{
    class CalendarMonthly : ÁbstractCalendar
    {

    }
}

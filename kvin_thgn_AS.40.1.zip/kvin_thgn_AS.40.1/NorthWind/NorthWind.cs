﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind
{
    /// <summary>
    /// Class retrieving/sending data from/to a repository implementing IRepository
    /// </summary>
    public class NorthWind
    {
        public List<Products> Products { get { return _repository.GetProducts(); } }
        public List<Orders> Orders { get { return _repository.GetOrders(); } }

        private readonly IRepository _repository;

        private delegate void NewOrderEventHandler(object sender, NewOrderEventArgs e);

        private static event NewOrderEventHandler NewOrderEvent;

        private NewOrderEventHandler _newOrderHandler = null;

        /// <summary>
        /// Creates a NorthWind object using the given repository.
        /// </summary>
        /// <param name="repository"></param>
        public NorthWind(IRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Adds an order to the repository, created from the given data.
        /// </summary>
        /// <param name="required"></param>
        /// <param name="name"></param>
        /// <param name="address"></param>
        /// <param name="city"></param>
        /// <param name="region"></param>
        /// <param name="postal"></param>
        /// <param name="country"></param>
        public void AddOrder(DateTime? required, string name, string address, string city, string region, string postal, string country)
        {
            var o = new Orders(DateTime.Now, required, name, address, city, region, postal, country);
            _repository.CreateOrder(o);
            var e = new NewOrderEventArgs { Order = o };
            if (NewOrderEvent != null) NewOrderEvent(this, e);
        }

        /// <summary>
        /// Adds a delegate to the NewOrderEvent
        /// </summary>
        public void Subscribe()
        {
            _newOrderHandler = NewOrderHandler;
            NewOrderEvent += _newOrderHandler;
        }

        /// <summary>
        /// Removes a delegate from the NewOrderEvent
        /// </summary>
        public void Unsubscribe()
        {
            NewOrderEvent -= _newOrderHandler;
        }

        /// <summary>
        /// Method used the the NewOrderEventHandler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void NewOrderHandler(object sender, NewOrderEventArgs e)
        {
            Console.WriteLine(e.Order.OrderID+", "+e.Order.OrderDate);
        }
    }
}

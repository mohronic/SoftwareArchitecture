﻿using System;

namespace Calendar_System.MainSystem
{
    class CalendarMonthly : ÁbstractCalendar
    {
        public override void Update()
        {
            throw new NotImplementedException();
        }
    }
}
